package com.pack.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

import com.pack.entity.Employee;
import com.pack.util.HibernateOGMUtil;

public class Test {

	public static void main(String[] args) {
		 EntityManagerFactory  entityManagerFactory = HibernateOGMUtil.getEntityManagerFactory();
		 
		 EntityManager em = entityManagerFactory.createEntityManager();
 
		 Employee employee = new Employee();
		 employee.setEid(7991);
		 employee.setName("KING");
		 employee.setSal(6000);
 
		 EntityTransaction tx=em.getTransaction();
		 tx.begin();
		 em.persist(employee);
		 tx.commit();
		 em.close();
		 HibernateOGMUtil.closeEntityManagerFactory();

	}

}
