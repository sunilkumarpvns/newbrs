package com.pack.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Employee {
 
	@Id
	private int eid;
 
	private String name;
 
	private  int  sal;
	
	
	 
	public int getSal() {
		return sal;
	}

	public void setSal(int sal) {
		this.sal = sal;
	}

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getName() {
		return name;
	}
 
	public void setName(String name) {
		this.name = name;
	}
 
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", name=" + name + "]";
	}
 
}
